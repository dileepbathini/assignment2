package org.example.controller;
import in.zeta.spectra.capture.SpectraLogger;
import olympus.trace.OlympusSpectra;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Scontroller {
    private static final SpectraLogger logger = OlympusSpectra.getLogger(Scontroller.class);

    @GetMapping("assignment-dileep-app/1.0/ping")
    public String ping() {
        logger.info("ping").log();
        return "my code is working";
    }
}
